# VoidScript - Studio MCP Proxy Fix - Update Report

- **App:** Void Script (VoidScript / VoidScript Bridge)
- **Package version:** 5.4.2 (bridge build 6.0.1)
- **Platform:** Windows
- **Date:** 2026-10-03
- **Revision:** 2 - corrected root cause (third-party launcher / Froststrap)
- **Issue:** `Client proxy is out of date, restart to update`

---

## 1. Summary

A one-click repair tool, **`Fix-Proxy.bat`**, was added to the app. It fixes the
Roblox-side error that stops VoidScript from driving Roblox Studio:

> `ERROR calling 'get_studio_state': Client proxy is out of date, restart to update`

**Root cause (corrected in revision 2):** this PC runs Roblox Studio through a
third-party launcher (**Froststrap**), which installs Studio into its own
`%LOCALAPPDATA%\Froststrap\Versions\...` folder. VoidScript's
`launch_studio_mcp.py` only looked in the *official*
`%LOCALAPPDATA%\Roblox\Versions`, so it kept launching a **months-old**
`StudioMCP.exe` (2026-05-08) against the **new** Froststrap Studio (2026-10-01).
Studio then answers every tool call with
`Client proxy is out of date, restart to update`.

The fix makes VoidScript launch the proxy that matches the *running* Studio, and
adds `Fix-Proxy.bat` to perform the same repair in one click.

---

## 2. Reported symptom

- VoidScript's bridge starts and the browser extension connects.
- Some calls still work (`list_roblox_studios` returned data).
- Every call that must reach the Studio app fails:

```
get_studio_state   -> Client proxy is out of date, restart to update
search_game_tree   -> Client proxy is out of date, restart to update
execute_luau       -> Client proxy is out of date, restart to update
```

- Raw stderr from Roblox's own `StudioMCP.exe` (forwarded by `bridge.py`):

```
WARN rmcp::service: response error id=8346
     error=ErrorData { code: ErrorCode(-32603),
     message: "Client proxy is out of date, restart to update", data: None }
```

---

## 3. Root cause

The error text is produced by **Roblox**, from the MCP stack (`rmcp`) inside
`StudioMCP.exe`. It means the **proxy** process talking to Studio is not the
build that belongs to the Studio that is running.

On this machine the mismatch was concrete:

| Component | Path | Build date |
| --------- | ---- | ---------- |
| Running Studio | `...\Froststrap\Versions\version-76e1a02649ad4f35\RobloxStudioBeta.exe` | 2026-10-01 |
| Proxy it launched | `...\Roblox\Versions\version-b087ddbc37e94847\StudioMCP.exe` | **2026-05-08** |

**Froststrap** (a Bloxstrap-family launcher) installs Studio to
`%LOCALAPPDATA%\Froststrap\Versions\`, *not* the official Roblox folder. That
official folder still held an old Studio + `StudioMCP.exe` from May.
`launch_studio_mcp.py` only scanned the official folder, so it launched the May
proxy. Roblox's own `mcp.bat` (written by Studio's Assistant) confirms the path
Studio expects:

```
%LOCALAPPDATA%\Froststrap\Versions\version-76e1a02649ad4f35\StudioMCP.exe
```

Secondary factor (also handled): leftover `StudioMCP.exe` processes from a
previous session keep Studio's MCP port, so the repair clears them too.

### Evidence from `logs/bridge_debug.log`

| When | What the log shows |
| ---- | ------------------ |
| 2026-10-01 | bridge v5.4.2, `29 tools advertised`, Studio connected, tools worked |
| 2026-10-02 | VoidScript auto-updated to v6.0.1; Studio MCP updated; proxy reported `0 tools advertised` / `Timed out waiting for tools to become available` |
| 2026-10-02 21:44 -> 23:39 | `Client proxy is out of date, restart to update` repeated **3,795** times |

Only one Studio version folder ever appears: `version-b087ddbc37e94847`, and the
bridge kept relaunching that same binary - so restarting the bridge alone could
not clear it.

---

## 4. What this update adds

| File | Change |
| ---- | ------ |
| `launch_studio_mcp.py` | **Fixed.** Now prefers the `StudioMCP.exe` sitting next to the *running* Studio, and scans every launcher's `Versions` folder (Froststrap, Bloxstrap, Voidstrap, Fishstrap, ...) - not just the official Roblox path. |
| `Fix-Proxy.bat` | **Added.** One-click repair for the "Client proxy is out of date" error. |
| `update-report.md` | **Added.** This document. |

---

## 5. What `Fix-Proxy.bat` does

1. **Cleans up leftover proxies** - kills any orphaned `StudioMCP.exe`
   (`taskkill /F /IM StudioMCP.exe`). This also lets Studio's updater run.
2. **Locates the correct proxy** - first the `StudioMCP.exe` sitting next to the
   **running** Studio (works for any launcher, incl. Froststrap/Bloxstrap); if no
   Studio is running, the newest real install (a folder containing `StudioMCP.exe`
   **and** `RobloxStudioBeta.exe`/`RobloxStudio.exe`) across every launcher's
   `Versions` folder. Falls back to any `StudioMCP.exe`.
3. **Pins it** - sets `VS_STUDIO_MCP_PATH` to that `StudioMCP.exe` (the
   documented override read by `launch_studio_mcp.py`) so the bridge launches the
   **matching** proxy instead of a stale one.
4. **Offers to close Studio** - if Studio is running it asks `[y/N]` (default
   No). Saying `y` closes `RobloxStudioBeta.exe` so Studio can finish updating
   on the next launch. It warns you to save your place first.
5. **Starts the bridge** - runs `start.bat` with the proxy pinned (inherits the
   environment, so the chosen `StudioMCP.exe` is used).
6. **Logs everything** to `logs/fix_proxy.log`.

It is safe to run repeatedly, and safe under the GUI launcher (`VS_GUI`).

---

## 6. How to use

1. Save your work.
2. Double-click **`Fix-Proxy.bat`**.
3. If Studio is running it will ask to close it - press `y` if you have saved.
4. When the bridge window is up, open Roblox Studio and let it finish updating.
5. In Studio: **Assistant Settings > MCP Servers > turn ON "Enable Studio as
   MCP server"** (this can flip off after an update), then **open a place**.
6. The bridge window turns **green** (`Roblox Studio connected`) when ready.

---

## 7. Verification

Verified live on 2026-10-03. With the patched launcher, the bridge log showed:

```
[roblox] stderr: launch_studio_mcp: using C:\...\Froststrap\Versions\version-76e1a02649ad4f35\StudioMCP.exe
[roblox] MCP server up  (28 tools advertised)
ready 30 tools available (1 MCP server(s))
Roblox Studio connected - 28 tools ready.
Place loaded in Studio.
```

- **Before:** `Client proxy is out of date, restart to update` repeated every few
  seconds (thousands of occurrences).
- **After:** **0** occurrences in the following minutes; Studio connected, place
  loaded, tools usable.

---

## 8. Rollback

- Delete `Fix-Proxy.bat` and `update-report.md`.
- If a specific `VS_STUDIO_MCP_PATH` was set, close the terminal (the value was
  only set for that window's session) - nothing is written to the system
  permanently.

---

## 9. Limitations / notes

- `Fix-Proxy.bat` cannot click Roblox's **Update** button for you; it clears the
  blockers and restarts the pieces so Studio can update, then you reopen Studio.
- It only changes environment for the process it launches; it does **not**
  persist `VS_STUDIO_MCP_PATH` system-wide (by design).
- This error is emitted by **Roblox**, not VoidScript. VoidScript itself was
  already current (v6.0.1) at the time of the report.
- **Durability:** VoidScript's auto-updater wipes the app folder on a new release
  (it preserves only `config.json`, `logs/`, `update.py`, `update.bat`). A future
  VoidScript update will therefore overwrite the `launch_studio_mcp.py` fix and
  delete `Fix-Proxy.bat` / `update-report.md`. Keep a copy of `Fix-Proxy.bat`
  outside the folder and re-run it after any VoidScript update. (At the time of
  writing there is no newer release - latest is V6.0.1.)

---

## 10. Appendix: files in this package

```
Void-Script-5.4.2/
  Fix-Proxy.bat            (new - this update)
  update-report.md         (new - this update)
  start.bat
  update.bat / update.py
  bridge.py
  launch_studio_mcp.py
  creatives.py
  config.json / check_update.json
  VoidScript.exe / index.html
  README.md / REBUILD.md / CHANGELOG.md / LICENSE
  MacOS_Start.command
  assets/  voidscript-extension/  logs/  backups/  __pycache__/
```

