:: SPDX-License-Identifier: GPL-3.0-or-later
:: Fix-Proxy.bat
:: ---------------------------------------------------------------------------
:: One-click fix for the Roblox-side error:
::     "Client proxy is out of date, restart to update"
::
:: That message comes from Roblox Studio's OWN MCP server (the Rust `rmcp`
:: service inside StudioMCP.exe). It means the local MCP proxy process that
:: VoidScript launched is an older build than the Roblox Studio that is now
:: running - usually because Studio auto-updated but the StudioMCP.exe being
:: launched is from a stale version folder, or leftover StudioMCP.exe
:: processes are blocking Studio's updater.
::
:: Common cause: a third-party Roblox launcher ("bootstrapper" - Froststrap,
:: Bloxstrap, ...) installed Studio into its OWN folder, while VoidScript kept
:: launching the OLD StudioMCP.exe from the official Roblox folder. Matching
:: the proxy to the Studio that is actually running is the whole point.
::
:: What this script does automatically:
::   1. Kills leftover (orphaned) StudioMCP.exe processes.
::   2. Finds the StudioMCP.exe of the Studio that is ACTUALLY RUNNING (or, if
::      none is running, the newest real install across every launcher's
::      Versions folder: Froststrap, Bloxstrap, official Roblox, ...) and pins
::      it with VS_STUDIO_MCP_PATH, so the bridge launches the MATCHING proxy.
::   3. Offers to close Roblox Studio so it can finish updating.
::   4. Starts the bridge with that proxy pinned.
:: ---------------------------------------------------------------------------
@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
title VoidScript  -  fix Studio MCP proxy
cd /d "%~dp0"

:: ---- palette (same as start.bat) ----
for /f %%e in ('echo prompt $E ^| cmd') do set "E=%%e"
set "C0=%E%[0m"
set "CB=%E%[1m"
set "CRED=%E%[38;2;255;90;82m"
set "CVIO=%E%[38;2;124;140;255m"
set "CWHT=%E%[38;2;236;236;242m"
set "CDIM=%E%[38;2;120;120;140m"
set "COK=%E%[38;2;52;211;153m"
set "CWARN=%E%[38;2;251;191;36m"

set "LOGDIR=%~dp0logs"
set "LOG=%LOGDIR%\fix_proxy.log"
if not exist "%LOGDIR%" md "%LOGDIR%" >nul 2>nul
call :note "==== %DATE% %TIME%  Fix-Proxy started ===="

echo.
echo   %CB%%CWHT%VoidScript%C0% %CDIM%-%C0% %CB%Fix the Studio MCP proxy%C0%
echo   %CDIM%targets: "Client proxy is out of date, restart to update"%C0%
echo.

:: ---- 0. sanity: are we in the project folder? ----
if not exist "%~dp0bridge.py" (
    call :fail "bridge.py is not next to Fix-Proxy.bat."
    echo   Extract the whole ZIP first, then run Fix-Proxy.bat from the folder.
    call :note "ABORT: bridge.py missing."
    call :halt 1
    exit /b 1
)

:: ---- 1. kill orphaned StudioMCP.exe ----
echo   %CVIO%[1/4]%C0% %CB%Cleaning up leftover StudioMCP.exe proxies...%C0%
tasklist /FI "IMAGENAME eq StudioMCP.exe" 2>nul | find /i "StudioMCP.exe" >nul
if errorlevel 1 (
    echo         %CDIM%none running.%C0%
    call :note "no StudioMCP.exe running."
) else (
    taskkill /F /IM StudioMCP.exe >nul 2>nul
    echo         %COK%cleaned up.%C0%
    call :note "killed leftover StudioMCP.exe process(es)."
)

:: ---- 2. find the CORRECT Studio MCP proxy ----
:: The right proxy is the StudioMCP.exe shipped WITH the Studio that is actually
:: running. Third-party launchers (Froststrap/Bloxstrap/...) put Studio in their
:: OWN folder, so the official Roblox folder can hold a months-old StudioMCP.exe
:: - launching that is what produces "Client proxy is out of date".
echo   %CVIO%[2/4]%C0% %CB%Locating the current Studio MCP proxy...%C0%
set "MCPEXE="

:: 2a. Preferred: the proxy that sits next to the RUNNING Studio executable.
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "(Get-Process RobloxStudioBeta,RobloxStudio -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Path)" 2^>nul`) do (
    if not defined MCPEXE if exist "%%~dpPStudioMCP.exe" set "MCPEXE=%%~dpPStudioMCP.exe"
)

:: 2b. Fallback: newest StudioMCP.exe in a REAL (paired) install folder, across
::     every launcher's Versions folder.
for %%R in (
    "%LOCALAPPDATA%\Froststrap\Versions"
    "%LOCALAPPDATA%\Bloxstrap\Versions"
    "%LOCALAPPDATA%\Voidstrap\Versions"
    "%LOCALAPPDATA%\Fishstrap\Versions"
    "%LOCALAPPDATA%\Roblox\Versions"
    "%ProgramFiles%\Roblox\Versions"
    "%ProgramFiles(x86)%\Roblox\Versions"
) do (
    if not defined MCPEXE if exist "%%~R" (
        for /f "delims=" %%V in ('dir /b /ad /o-d "%%~R" 2^>nul ^| findstr /i /b "version-"') do (
            if not defined MCPEXE if exist "%%~R\%%V\StudioMCP.exe" (
                if exist "%%~R\%%V\RobloxStudioBeta.exe" set "MCPEXE=%%~R\%%V\StudioMCP.exe"
                if exist "%%~R\%%V\RobloxStudio.exe" set "MCPEXE=%%~R\%%V\StudioMCP.exe"
            )
        )
    )
)

:: 2c. Last resort: any StudioMCP.exe (even an unpaired "zombie" folder).
if not defined MCPEXE (
    for %%R in (
        "%LOCALAPPDATA%\Froststrap\Versions"
        "%LOCALAPPDATA%\Bloxstrap\Versions"
        "%LOCALAPPDATA%\Roblox\Versions"
    ) do (
        if not defined MCPEXE if exist "%%~R" (
            for /f "delims=" %%V in ('dir /b /ad /o-d "%%~R" 2^>nul ^| findstr /i /b "version-"') do (
                if not defined MCPEXE if exist "%%~R\%%V\StudioMCP.exe" set "MCPEXE=%%~R\%%V\StudioMCP.exe"
            )
        )
    )
)

if defined MCPEXE (
    set "VS_STUDIO_MCP_PATH=%MCPEXE%"
    echo         %COK%using:%C0% %CDIM%%MCPEXE%%C0%
    call :note "pinned VS_STUDIO_MCP_PATH=%MCPEXE%"
) else (
    echo         %CWARN%No StudioMCP.exe found.%C0%
    call :note "WARN: no StudioMCP.exe found."
)

:: ---- 3. offer to close Studio so it can finish updating ----
echo   %CVIO%[3/4]%C0% %CB%Checking Roblox Studio...%C0%
tasklist /FI "IMAGENAME eq RobloxStudioBeta.exe" 2>nul | find /i "RobloxStudioBeta.exe" >nul
if errorlevel 1 (
    echo         %CDIM%Studio is not running.%C0%
    call :note "Studio not running."
) else (
    echo         %CWARN%Roblox Studio is running.%C0%
    echo         Studio should be FULLY restarted so it can finish updating and its
    echo         proxy version matches. SAVE YOUR PLACE before continuing.
    if not defined VS_GUI (
        set "ANS="
        set /p "ANS=         Close Roblox Studio now? [y/N] "
        if /i "!ANS!"=="y" (
            taskkill /F /IM RobloxStudioBeta.exe >nul 2>nul
            ping -n 2 127.0.0.1 >nul
            echo         %COK%Studio closed.%C0% Reopen it after the bridge starts.
            call :note "closed RobloxStudioBeta.exe at user request."
        ) else (
            echo         %CDIM%Leaving Studio open - remember to restart it yourself.%C0%
            call :note "user kept Studio open."
        )
    )
)

:: ---- 4. action box + start bridge ----
echo.
echo   %CWARN%== ACTION NEEDED ==%C0%
echo   %CWHT% 1.%C0% Open Roblox Studio and let it finish updating first.
echo   %CWHT% 2.%C0% Assistant Settings, then MCP Servers
echo   %CWHT% 3.%C0% turn ON  'Enable Studio as MCP server'
echo   %CWHT% 4.%C0% Open a place - the bridge window turns green when connected.
echo.
echo   %CVIO%[4/4]%C0% %CB%Starting the bridge...%C0%
call :note "launching start.bat with VS_STUDIO_MCP_PATH=%MCPEXE%"
call "%~dp0start.bat"
set "RC=%errorlevel%"
call :note "start.bat returned %RC%"
exit /b %RC%


:: ===========================================================================
::  subroutines
:: ===========================================================================
:fail
echo.
echo   %CRED%ERROR:%C0% %~1
echo.
exit /b 0

:note
>>"%LOG%" 2>nul echo(%~1
exit /b 0

:halt
if defined VS_GUI exit /b %~1
echo   Press any key to close.
pause >nul
exit /b %~1
