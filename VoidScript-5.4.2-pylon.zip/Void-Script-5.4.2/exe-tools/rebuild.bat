@echo off
setlocal
cd /d "%~dp0.."
where node >nul 2>nul || (echo Node.js 18 or newer is required: https://nodejs.org & pause & exit /b 1)
node exe-tools\build-exe.js exe-tools\VoidScript.original.exe ui-src VoidScript.new.exe ^
  --icons exe-tools\icons ^
  --text "VoidScript - AI agent for Roblox Studio" "Pylon - Your AI agent for Roblox Studio" ^
  --text "Open VoidScript" "Open Pylon app" ^
  --text "Quit VoidScript" "Quit Pylon app" ^
  --text "starting VoidScript bridge (" "starting Pylon bridge with (" ^
  --text "Choose the workspace folder VoidScript may use" "Choose the workspace folder Pylon may use"
if errorlevel 1 (echo. & echo Build failed - nothing was changed. & pause & exit /b 1)
move /y VoidScript.new.exe VoidScript.exe >nul || (echo Could not replace VoidScript.exe - close Pylon first. & pause & exit /b 1)
echo. & echo Done. Start Pylon again.
pause
