"""Pylon logo: a glowing crystal obelisk inside a gradient ring.
Draws once at high resolution and downsamples, so every size stays crisp.
Outputs <out>/<N>x<N>.png for the sizes the exe embeds."""
import sys, os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

OUT = sys.argv[1] if len(sys.argv) > 1 else "icons"
os.makedirs(OUT, exist_ok=True)

S = 2048                      # master canvas
K = S / 512.0                 # scale from the 512-unit design grid

CY = (46, 230, 255)           # cyan   #2ee6ff
BL = (91, 124, 255)           # azure  #5b7cff
DEEP = (7, 12, 24)


def lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def gradient(size, c0, c1, angle_deg=45.0):
    """Linear gradient image (RGBA) from c0 to c1 along angle."""
    w, h = size
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    a = np.deg2rad(angle_deg)
    t = (xx * np.cos(a) + yy * np.sin(a))
    t = (t - t.min()) / (t.max() - t.min() + 1e-9)
    out = np.zeros((h, w, 4), np.uint8)
    for i in range(3):
        out[..., i] = (c0[i] + (c1[i] - c0[i]) * t).astype(np.uint8)
    out[..., 3] = 255
    return Image.fromarray(out, "RGBA")


def poly(points):
    return [(x * K, y * K) for x, y in points]


def mask_poly(points):
    m = Image.new("L", (S, S), 0)
    ImageDraw.Draw(m).polygon(poly(points), fill=255)
    return m


def build():
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))

    # 1. dark disc with a soft radial lift in the middle
    disc = Image.new("L", (S, S), 0)
    ImageDraw.Draw(disc).ellipse((2 * K, 2 * K, 510 * K, 510 * K), fill=255)
    yy, xx = np.mgrid[0:S, 0:S].astype(np.float32)
    r = np.sqrt((xx - S / 2) ** 2 + (yy - S * 0.46) ** 2) / (S * 0.55)
    r = np.clip(r, 0, 1)
    base = np.zeros((S, S, 4), np.uint8)
    inner, outer = (16, 30, 54), DEEP
    for i in range(3):
        base[..., i] = (inner[i] + (outer[i] - inner[i]) * r).astype(np.uint8)
    base[..., 3] = 255
    img.paste(Image.fromarray(base, "RGBA"), (0, 0), disc)

    # 2. gradient ring
    ring = Image.new("L", (S, S), 0)
    d = ImageDraw.Draw(ring)
    d.ellipse((2 * K, 2 * K, 510 * K, 510 * K), fill=255)
    d.ellipse((30 * K, 30 * K, 482 * K, 482 * K), fill=0)
    img.paste(gradient((S, S), CY, BL, 50), (0, 0), ring)

    # 3. glow behind the crystal
    glow = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.polygon(poly([(256, 78), (338, 238), (256, 438), (174, 238)]), fill=CY + (150,))
    glow = glow.filter(ImageFilter.GaussianBlur(34 * K))
    clip = Image.new("L", (S, S), 0)
    ImageDraw.Draw(clip).ellipse((34 * K, 34 * K, 478 * K, 478 * K), fill=255)
    glow.putalpha(Image.fromarray(
        (np.array(glow.getchannel("A"), np.float32) * (np.array(clip, np.float32) / 255)).astype(np.uint8)))
    img = Image.alpha_composite(img, glow)

    # 4. crystal obelisk: tall faceted diamond split into a lit and a shaded half
    T, R, B, L = (256, 84), (326, 236), (256, 424), (186, 236)
    M = (256, 236)                                    # waist
    left = mask_poly([T, M, B, L])
    right = mask_poly([T, R, B, M])
    img.paste(gradient((S, S), (24, 150, 214), (22, 96, 190), 90), (0, 0), left)
    img.paste(gradient((S, S), (120, 244, 255), CY, 90), (0, 0), right)
    # bright upper facet on the lit side
    img.paste(Image.new("RGBA", (S, S), (235, 253, 255, 255)), (0, 0),
              mask_poly([T, R, (292, 160), (256, 120)]).point(lambda v: int(v * 0.85)))
    # hairline edge down the middle for crispness
    ImageDraw.Draw(img).line(poly([T, B]), fill=(220, 250, 255, 255), width=int(3.2 * K))

    # 5. floating base bar under the crystal
    bar = Image.new("L", (S, S), 0)
    ImageDraw.Draw(bar).rounded_rectangle((176 * K, 442 * K, 336 * K, 456 * K), radius=7 * K, fill=255)
    img.paste(gradient((S, S), CY, BL, 0), (0, 0), bar)
    return img


master = build()
for n in (512, 256, 128, 64, 48, 32, 24, 16):
    im = master.resize((n, n), Image.LANCZOS)
    im.save(os.path.join(OUT, f"{n}x{n}.png"), optimize=True)
    print(n, os.path.getsize(os.path.join(OUT, f"{n}x{n}.png")), "bytes")
