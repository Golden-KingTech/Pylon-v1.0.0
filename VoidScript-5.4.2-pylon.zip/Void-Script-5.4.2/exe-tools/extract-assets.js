// node extract-assets.js <VoidScript.exe> <out-dir>
const fs = require("fs"), path = require("path");
const { parsePE, findAssets } = require("./tauri-assets");
const [exe, out] = process.argv.slice(2);
if (!exe || !out) { console.error("usage: node extract-assets.js <exe> <out-dir>"); process.exit(2); }
const buf = fs.readFileSync(exe), h = parsePE(buf);
const assets = findAssets(buf, h);
if (!assets.length) { console.error("no embedded assets found (not a Tauri 2 exe?)"); process.exit(1); }
for (const a of assets) {
  const dest = path.join(out, a.key.replace(/^\//, ""));
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(dest, a.data);
  console.log(`${a.key.padEnd(24)} ${String(a.data.length).padStart(8)} bytes  (compressed ${a.blobLen})`);
}
console.log(`\nExtracted ${assets.length} assets to ${out}`);
