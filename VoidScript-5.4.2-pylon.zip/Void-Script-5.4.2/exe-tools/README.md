# Pylon (VoidScript.exe): what changed and how to change it again

## What is different

**Studio proxy fix, built in** (`bridge.py` + Home tab)
- **Fix proxy** button on Home. It stops the stale Studio proxy, closes a leftover `StudioMCP.exe`
  that holds Studio's port (only ever a StudioMCP.exe), starts the proxy that sits next to the
  *running* Studio, then verifies with a real Studio call. Each step is shown and logged.
- Automatic repair: if Roblox answers "Client proxy is out of date", the bridge repairs it and
  retries (at most once every 45 s). Bridge not running: the button starts it. Older bridge:
  falls back to a restart.

**Corner roundness** (Settings > App)
- One slider, 0% to 200%, drives every corner in the app. Presets: Sharp / Default / Soft / Round.
- Live while dragging, saved when you let go. Works in both themes.
- 100% is the designed look. Pills (toggles, chips, badges) stay fully round until the slider
  gets low, then square up smoothly. Status dots and spinners are circles at 100% and up, and
  soften toward squares below it.
- Stored in the app's local storage on this PC (key `vs-radius`), not in the app's settings file.

**Prompt enhancer** (sidebar > Enhancer)
- Type a rough idea, pick a style (Clear / Detailed / Short), press Enhance (or Ctrl+Enter).
  It rewrites the idea into a clear build prompt for a Roblox Studio agent.
- It uses the provider, API key and model you chose in Settings (NVIDIA, OpenRouter or Google),
  through the same call path as the chat, so a retired model is swapped automatically. No key:
  it tells you and links to Settings. Nothing is sent to Studio.
- The result is editable. Use in Chat puts it in the chat box (it does not send), Copy, and
  Refine again moves it back to the left to improve it further. Stop cancels a run.
- Your last 15 enhancements are kept on this PC (Clear history removes them); an unsent draft
  survives restarts.

**Pylon theme** (default; the "OR" partner theme is unchanged)
- Deep navy panels, electric cyan to azure accent, faint blueprint grid, dark text on bright
  buttons (contrast checked: 5.3:1 minimum on the gradient). All colours are the variables at
  the top of `ui-src/styles.css`.

**Rename to Pylon**
- Everywhere users read text: window title, title bar, tray menu, Settings, Home, Chat, help
  text, the in-app AI's persona, the Terminal's "starting ... bridge" line, new logo and icons
  (window, tray, exe/taskbar: 16 to 512 px).

## Updates no longer delete your files
Every update path (the Update button, `update.bat`, and the automatic check `start.bat` runs on
each launch) goes through `update.py`. Before, it kept only `config.json` and `logs/`.
- `preserve.txt` lists the top-level names to keep: `exe-tools`, `ui-src`, `backups`,
  `Fix-Proxy.bat`, `update-report.md`. Add your own, one per line.
- `@name` entries (`VoidScript.exe`, `bridge.py`, `launch_studio_mcp.py`) are files the release
  replaces. Your edited copy is first saved to `pylon-saved\<date>-<version>\` (newest 3 kept).
- A release's own `update.py` would drop this protection, so the updater patches the new
  `update.py` after each update. If it ever cannot, it keeps the previous updater and saves the
  release's as `update.upstream.py`. What happened is logged in `logs\update-preserve.log`.
- `backups\` is now kept too (place backups used to be deleted by every update).
- Not preserved: names not listed (as before). Files the release also ships are replaced by the
  release's version, so after an update the app is the upstream VoidScript again; your Pylon
  `VoidScript.exe` and `bridge.py` are waiting in `pylon-saved\`.

## Deliberately NOT renamed
- `app.voidscript.desktop`, `voidscript-settings.json`: the app's identity and settings file.
  Renaming them would reset every saved setting (and the roundness slider value).
- `VoidScript.exe` and the folder name: the exe filename; error texts refer to it.
- `ServerStorage.VoidScript.Memory` in Studio: shared with the browser extension and with games
  that already have a memory. Same for Roblox instance names the Toolkit creates and cleans up
  (`VoidScriptAtmosphere`, `VoidScriptGui`, ...).
- The browser extension, `bridge.py` banners, `start.bat`, GitHub/website links, and a few rare
  error messages inside the compiled exe. Changing compiled text needs the same length; the
  visible ones were done, the rest were left.

## Change the UI again
1. Edit `ui-src/` (`index.html`, `app.js`, `styles.css`, ...).
2. Needs Node.js 18+. Close the app, then double-click `exe-tools\rebuild.bat`.
3. It always builds from `exe-tools\VoidScript.original.exe` and re-reads its own output,
   deleting it if anything fails to decode or any unexpected byte changed.

Limits: existing asset files only (no new files, no new Rust commands without the source). Keep
scripts out of `index.html`. Text patches must fit the original byte length (padded with spaces).
Logo: `python exe-tools\make_logo.py exe-tools\icons` needs Pillow + numpy (optional).

## Roll back
Copy `exe-tools\VoidScript.original.exe` over `VoidScript.exe`. `bridge.py` still works with it.

## Heads-up
- Not launched on Windows by the author of this patch. Verified by decoding every asset and icon
  back out of the built exe, a standard PE reader, and automated tests of the bridge repair,
  the Fix proxy button and the slider logic, not by running the app. The theme preview image is
  a mock of the palette, not a screenshot.
- Updating from inside the app (or `update.py`) replaces this folder with the upstream release
  and removes all of this. Keep this zip.
