// node build-exe.js <original.exe> <assets-dir> <out.exe> [--text OLD NEW]... [--icons DIR]
//
//  * assets-dir : every file whose content differs from the original replaces that UI asset.
//                 New blobs go into a new read-only section (.vsui); the asset table entries
//                 are repointed there. Unknown files are refused (a NEW asset path would need
//                 the table rebuilt, which needs the Rust source).
//  * --text     : same-length text patch. OLD must occur exactly once in the exe; NEW may be
//                 shorter (padded with trailing spaces) but never longer, because string
//                 lengths live in compiled code.
//  * --icons    : directory of <W>x<H>.png. Each replaces the embedded icon PNG of that size
//                 in place, padded to the exact old byte length with an ignorable PNG chunk.
//
// The original file is never modified. The output is re-read from scratch and verified;
// it is deleted if anything fails to decode or any byte outside the patched spots changed.
"use strict";
const fs = require("fs"), path = require("path"), zlib = require("zlib");
const { parsePE, findAssets, alignUp, walkPng, findPngs, padPngTo } = require("./tauri-assets");

// ---- args -------------------------------------------------------------------
const argv = process.argv.slice(2), pos = [], texts = []; let iconsDir = null;
for (let i = 0; i < argv.length; i++) {
  if (argv[i] === "--text") { texts.push([argv[i + 1], argv[i + 2]]); i += 2; }
  else if (argv[i] === "--icons") { iconsDir = argv[++i]; }
  else pos.push(argv[i]);
}
const [src, dir, dst] = pos;
if (!src || !dir || !dst || texts.some(([a, b]) => a == null || b == null)) {
  console.error("usage: node build-exe.js <original.exe> <assets-dir> <out.exe> [--text OLD NEW]... [--icons DIR]"); process.exit(2);
}
if (path.resolve(src) === path.resolve(dst)) { console.error("refusing to overwrite the original: pick another output path"); process.exit(2); }

const buf = fs.readFileSync(src);
const h = parsePE(buf);
if (h.secDirSize) throw new Error("exe is Authenticode-signed; patching would break the signature");
if (h.secs.some((s) => s.name === ".vsui")) throw new Error("exe already has a .vsui section - patch from the ORIGINAL exe");
const assets = findAssets(buf, h);
const byKey = new Map(assets.map((a) => [a.key, a]));
if (!assets.length) throw new Error("no embedded assets found");

// ---- 1. UI asset changes ------------------------------------------------------
const files = [];
(function walk(d, rel) {
  for (const n of fs.readdirSync(d)) {
    const p = path.join(d, n), r = rel + "/" + n;
    if (fs.statSync(p).isDirectory()) walk(p, r); else files.push([r, p]);
  }
})(dir, "");
const changes = [];
for (const [key, p] of files) {
  const a = byKey.get(key);
  if (!a) throw new Error(`"${key}" is not an asset of this exe (cannot add new assets without the Rust source)`);
  const data = fs.readFileSync(p);
  if (!data.equals(a.data)) changes.push({ a, data });
}

// ---- 2. same-length text patches ----------------------------------------------
const textPatches = [];
for (const [oldS, newS] of texts) {
  const ob = Buffer.from(oldS, "utf8"), nb0 = Buffer.from(newS, "utf8");
  if (nb0.length > ob.length) throw new Error(`--text: "${newS}" is longer than "${oldS}" (${nb0.length} > ${ob.length}); string lengths are compiled in`);
  const nb = Buffer.concat([nb0, Buffer.alloc(ob.length - nb0.length, 0x20)]);
  const at = buf.indexOf(ob);
  let n = 0;
  for (let p = at; p !== -1; p = buf.indexOf(ob, p + 1)) n++;
  if (n !== 1) throw new Error(`--text: "${oldS}" occurs ${n} times (need exactly 1)`);
  textPatches.push({ at, old: ob, nb });
}

// ---- 3. icon PNGs, in place -----------------------------------------------------
const iconPatches = [];
if (iconsDir) {
  const inBlob = (o) => assets.some((a) => o >= a.blobOff && o < a.blobOff + a.blobLen);
  for (const p of findPngs(buf)) {
    if (inBlob(p.off)) continue;                                   // belongs to a UI asset, handled above
    const f = path.join(iconsDir, `${p.w}x${p.h}.png`);
    if (!fs.existsSync(f)) continue;
    const png = fs.readFileSync(f), info = walkPng(png, 0);
    if (!info || info.end !== png.length) throw new Error(`${f} is not a clean PNG`);
    if (info.w !== p.w || info.h !== p.h) throw new Error(`${f} must be ${p.w}x${p.h}`);
    const fitted = padPngTo(png, p.end - p.off);
    if (!fitted) throw new Error(`${f} (${png.length} bytes) does not fit the ${p.end - p.off}-byte slot of the ${p.w}x${p.h} icon`);
    iconPatches.push({ ...p, data: fitted });
  }
}

if (!changes.length && !textPatches.length && !iconPatches.length) { console.log("Nothing differs from the original - nothing to do."); process.exit(0); }

// ---- build the output ---------------------------------------------------------
let out, sh = -1, newRVA = 0, newRawPtr = 0, dataLen = 0;
const blobs = [];
if (changes.length) {
  let cursor = 0;
  for (const c of changes) {
    const comp = zlib.brotliCompressSync(c.data, { params: {
      [zlib.constants.BROTLI_PARAM_QUALITY]: 11,
      [zlib.constants.BROTLI_PARAM_LGWIN]: 22,
      [zlib.constants.BROTLI_PARAM_SIZE_HINT]: c.data.length } });
    if (!zlib.brotliDecompressSync(comp).equals(c.data)) throw new Error("brotli round-trip failed for " + c.a.key);
    cursor = alignUp(cursor, 16);
    blobs.push({ ...c, comp, at: cursor });
    cursor += comp.length;
  }
  dataLen = cursor;
  newRVA = alignUp(h.sizeOfImage, h.secAlign);
  newRawPtr = alignUp(buf.length, h.fileAlign);
  const rawSize = alignUp(dataLen, h.fileAlign);
  if (h.secs[0].rptr - (h.secTable + h.nsec * 40) < 40) throw new Error("no room for another section header");
  out = Buffer.alloc(newRawPtr + rawSize);
  buf.copy(out, 0);
  for (const b of blobs) b.comp.copy(out, newRawPtr + b.at);
  sh = h.secTable + h.nsec * 40;
  out.write(".vsui", sh, "latin1");
  out.writeUInt32LE(dataLen, sh + 8);
  out.writeUInt32LE(newRVA, sh + 12);
  out.writeUInt32LE(rawSize, sh + 16);
  out.writeUInt32LE(newRawPtr, sh + 20);
  out.writeUInt32LE(0x40000040, sh + 36);                          // INITIALIZED_DATA | MEM_READ
  out.writeUInt16LE(h.nsec + 1, h.pe + 6);
  out.writeUInt32LE(alignUp(newRVA + dataLen, h.secAlign), h.opt + 56);
  out.writeUInt32LE(out.readUInt32LE(h.opt + 8) + rawSize, h.opt + 8);
  for (const b of blobs) {                                          // repoint (pointer keeps its relocation entry)
    out.writeBigUInt64LE(BigInt(h.imageBase + newRVA + b.at), b.a.entryOff + 16);
    out.writeBigUInt64LE(BigInt(b.comp.length), b.a.entryOff + 24);
  }
} else {
  out = Buffer.from(buf);
}
for (const t of textPatches) t.nb.copy(out, t.at);
for (const p of iconPatches) p.data.copy(out, p.off);
fs.writeFileSync(dst, out);

// ---- self-verification: re-read the OUTPUT from scratch ------------------------
let bad = 0;
const fail = (m) => { console.error("FAIL " + m); bad++; };
const vb = fs.readFileSync(dst), vh = parsePE(vb), va = findAssets(vb, vh);
const vmap = new Map(va.map((a) => [a.key, a]));
if (va.length !== assets.length) fail(`asset count ${va.length} != ${assets.length}`);
for (const a of assets) {
  const n = vmap.get(a.key), ch = blobs.find((b) => b.a.key === a.key);
  if (!n || !n.data.equals(ch ? ch.data : a.data)) fail("asset content mismatch: " + a.key);
}
const touched = [];
for (const b of blobs) touched.push([b.a.entryOff + 16, b.a.entryOff + 32]);
if (changes.length) touched.push([h.pe + 6, h.pe + 8], [h.opt + 8, h.opt + 12], [h.opt + 56, h.opt + 60], [sh, sh + 40]);
for (const t of textPatches) {
  touched.push([t.at, t.at + t.old.length]);
  if (!vb.subarray(t.at, t.at + t.old.length).equals(t.nb)) fail("text patch not applied at 0x" + t.at.toString(16));
}
const vpngs = findPngs(vb);
for (const p of iconPatches) {
  touched.push([p.off, p.end]);
  const v = vpngs.find((x) => x.off === p.off);
  if (!v || v.end !== p.end || v.w !== p.w || v.h !== p.h) fail(`icon ${p.w}x${p.h} is not a valid PNG of the same size at the same place`);
}
let diffs = 0;
for (let i = 0; i < buf.length; i++) {
  if (buf[i] !== vb[i] && !touched.some(([a, b]) => i >= a && i < b)) { if (++diffs < 4) console.error("unexpected diff at 0x" + i.toString(16)); }
}
if (diffs) fail(`${diffs} unexpected byte differences`);
if (vh.sizeOfImage % vh.secAlign || (changes.length && vh.secs[vh.secs.length - 1].rptr % vh.fileAlign)) fail("alignment");
if (bad) { fs.unlinkSync(dst); console.error("verification failed - output deleted"); process.exit(1); }

for (const b of blobs) console.log(`asset  ${b.a.key.padEnd(14)} ${String(b.a.data.length).padStart(7)} -> ${String(b.data.length).padStart(7)} bytes (brotli ${b.a.blobLen} -> ${b.comp.length})`);
for (const t of textPatches) console.log(`text   "${t.old.toString()}" -> "${t.nb.toString().trimEnd()}"` + (t.nb.toString().endsWith(" ") ? " (+padding)" : ""));
for (const p of iconPatches) console.log(`icon   ${String(p.w + "x" + p.h).padEnd(8)} ${p.end - p.off} bytes (same size, in place)`);
console.log(`\nOK  ${dst}  (${vb.length} bytes)`);
console.log(`verified: ${va.length} assets decode, ${assets.length - blobs.length} untouched assets byte-identical, ${iconPatches.length} icons valid, no other bytes changed`);
