// tauri-assets.js - read the embedded front-end assets of a Tauri 2 exe and
// repoint modified ones. Shared by extract-assets.js / build-exe.js / verify.
//
// How Tauri 2 embeds the UI: a static table of 32-byte entries
//     [ key_ptr u64 | key_len u64 | blob_ptr u64 | blob_len u64 ]
// (key = "/app.js", blob = brotli stream) sits in .rdata. Pointers are absolute
// virtual addresses (ImageBase + RVA) and each one has a base-relocation entry.
"use strict";
const fs = require("fs");
const zlib = require("zlib");

function parsePE(buf) {
  if (buf.readUInt16LE(0) !== 0x5a4d) throw new Error("not an MZ/PE file");
  const pe = buf.readUInt32LE(0x3c);
  if (buf.toString("latin1", pe, pe + 4) !== "PE\0\0") throw new Error("bad PE signature");
  const nsec = buf.readUInt16LE(pe + 6);
  const optSize = buf.readUInt16LE(pe + 20);
  const opt = pe + 24;
  if (buf.readUInt16LE(opt) !== 0x20b) throw new Error("only PE32+ (x64) is supported");
  const h = {
    pe, nsec, opt, optSize,
    imageBase: Number(buf.readBigUInt64LE(opt + 24)),
    secAlign: buf.readUInt32LE(opt + 32),
    fileAlign: buf.readUInt32LE(opt + 36),
    sizeOfImage: buf.readUInt32LE(opt + 56),
    sizeOfHeaders: buf.readUInt32LE(opt + 60),
    secTable: opt + optSize,
    secs: [],
  };
  for (let i = 0; i < nsec; i++) {
    const o = h.secTable + i * 40;
    h.secs.push({
      name: buf.toString("latin1", o, o + 8).replace(/\0+$/, ""),
      vsize: buf.readUInt32LE(o + 8), va: buf.readUInt32LE(o + 12),
      rsize: buf.readUInt32LE(o + 16), rptr: buf.readUInt32LE(o + 20),
    });
  }
  // security directory (Authenticode) - patching would invalidate it
  h.secDirSize = buf.readUInt32LE(opt + 112 + 4 * 8 + 4);
  // base relocations
  const rr = buf.readUInt32LE(opt + 112 + 5 * 8), rs = buf.readUInt32LE(opt + 112 + 5 * 8 + 4);
  h.relocs = new Set();
  const r0 = rva2off(h, rr);
  for (let p = r0; r0 >= 0 && p < r0 + rs;) {
    const page = buf.readUInt32LE(p), blk = buf.readUInt32LE(p + 4);
    if (blk < 8) break;
    for (let j = 0; j < (blk - 8) / 2; j++) {
      const e = buf.readUInt16LE(p + 8 + 2 * j);
      if (e >> 12 === 10) h.relocs.add(page + (e & 0xfff));
    }
    p += blk;
  }
  return h;
}
function rva2off(h, rva) {
  for (const s of h.secs) if (rva >= s.va && rva < s.va + Math.max(s.vsize, s.rsize)) return s.rptr + (rva - s.va);
  return -1;
}
const va2off = (h, va) => rva2off(h, va - h.imageBase);
const off2rva = (h, off) => { for (const s of h.secs) if (off >= s.rptr && off < s.rptr + s.rsize) return s.va + (off - s.rptr); return -1; };

function brotliAt(buf, off, maxLen) {
  const r = zlib.brotliDecompressSync(buf.subarray(off, off + maxLen), { info: true });
  return { data: r.buffer, used: r.engine.bytesWritten };
}

// Find every embedded asset: { key, entryOff, blobOff, blobLen, data }
function findAssets(buf, h) {
  h = h || parsePE(buf);
  const out = [];
  const rdata = h.secs.find((s) => s.name === ".rdata");
  if (!rdata) throw new Error("no .rdata section");
  const lo = rdata.rptr, hi = rdata.rptr + rdata.rsize - 32;
  const inImg = (v) => v >= h.imageBase && v < h.imageBase + h.sizeOfImage;
  for (let o = lo; o <= hi; o += 8) {
    const kp = Number(buf.readBigUInt64LE(o)), kl = Number(buf.readBigUInt64LE(o + 8));
    if (kl < 2 || kl > 80 || !inImg(kp)) continue;
    const ko = va2off(h, kp);
    if (ko < 0 || buf[ko] !== 0x2f) continue;                       // keys start with "/"
    const key = buf.toString("latin1", ko, ko + kl);
    if (!/^\/[\w.\-\/]+$/.test(key)) continue;
    const bp = Number(buf.readBigUInt64LE(o + 16)), bl = Number(buf.readBigUInt64LE(o + 24));
    if (bl < 1 || bl > 8e6 || !inImg(bp)) continue;
    const bo = va2off(h, bp);
    if (bo < 0 || !h.relocs.has(off2rva(h, o + 16))) continue;      // pointer must be relocated
    try {
      const { data, used } = brotliAt(buf, bo, bl);
      if (used !== bl) continue;                                     // stream must fill the slice exactly
      out.push({ key, entryOff: o, blobOff: bo, blobLen: bl, data });
    } catch (e) { /* not an asset entry */ }
  }
  return out;
}

const alignUp = (n, a) => Math.ceil(n / a) * a;

// ---- PNG helpers (embedded window/tray/exe icons are raw PNG streams) ----------
const CRC_T = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(b) { let c = 0xffffffff; for (let i = 0; i < b.length; i++) c = CRC_T[(c ^ b[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
const PNG_SIG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

// Walk a PNG starting at `off`; returns {w,h,end} (end = byte after IEND) or null if it is not a fully valid PNG.
function walkPng(buf, off) {
  if (off < 0 || off + 33 > buf.length || buf.compare(PNG_SIG, 0, 8, off, off + 8) !== 0) return null;
  let p = off + 8, first = true, w = 0, h = 0;
  while (p + 12 <= buf.length) {
    const len = buf.readUInt32BE(p), type = buf.toString("latin1", p + 4, p + 8);
    if (len > 8e6 || p + 12 + len > buf.length) return null;
    if (first) { if (type !== "IHDR" || len !== 13) return null; w = buf.readUInt32BE(p + 8); h = buf.readUInt32BE(p + 12); first = false; }
    if (crc32(buf.subarray(p + 4, p + 8 + len)) !== buf.readUInt32BE(p + 8 + len)) return null;
    p += 12 + len;
    if (type === "IEND") return { w, h, end: p };
  }
  return null;
}
// All fully valid PNG streams in the file: [{off, end, w, h}]
function findPngs(buf) {
  const out = []; let pos = 0;
  while ((pos = buf.indexOf(PNG_SIG, pos)) !== -1) {
    const r = walkPng(buf, pos);
    if (r && r.w > 0 && r.w <= 4096 && r.h > 0 && r.h <= 4096) { out.push({ off: pos, end: r.end, w: r.w, h: r.h }); pos = r.end; } else pos += 8;
  }
  return out;
}
// Re-encode `png` to exactly `size` bytes by inserting a private ancillary chunk before IEND
// (decoders skip it). Returns null when it cannot fit / the gap is 1..11 bytes (smaller than a chunk).
function padPngTo(png, size) {
  const gap = size - png.length;
  if (gap < 0 || (gap > 0 && gap < 12)) return null;
  if (gap === 0) return png;
  const dataLen = gap - 12, chunk = Buffer.alloc(gap);
  chunk.writeUInt32BE(dataLen, 0); chunk.write("pyLn", 4, "latin1");           // ancillary, private, safe-to-copy
  chunk.writeUInt32BE(crc32(chunk.subarray(4, 8 + dataLen)), 8 + dataLen);
  return Buffer.concat([png.subarray(0, png.length - 12), chunk, png.subarray(png.length - 12)]);
}

module.exports = { parsePE, findAssets, rva2off, va2off, off2rva, alignUp, crc32, walkPng, findPngs, padPngTo };
