#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
# update.py - VoidScript auto-updater.
#
#   python update.py --auto    fully automatic mode (used by start.bat):
#                              silently downloads+applies a newer release and
#                              prints UPDATE_APPLIED <tag> only when it did;
#                              nothing is printed when up to date and errors
#                              never block startup.
#   python update.py --check   non-intrusive check: prints UPDATE_AVAILABLE
#                              <tag> when a newer release exists, otherwise
#                              nothing. Never downloads.
#   python update.py           full update: download the latest release asset,
#                              extract it, and swap it over the project (keeping
#                              config.json, logs/ and .git).
#
# Uses ONLY the Python standard library, so no extra install is ever needed.
import json
import os
import re
import shutil
import sys
import tempfile
import time
import urllib.request
import zipfile

REPO = "cjl26rg2/Void-Script"
API = f"https://api.github.com/repos/{REPO}/releases/latest"
RELEASES_URL = f"https://github.com/{REPO}/releases"
STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "check_update.json")
# Only hit the API this often in --check mode (start.bat calls it every launch).
CHECK_TTL_SEC = 3600
# Paths that must never be overwritten by a release swap.
# >>> pylon-preserve (begin)
# Keeps the files you added to this folder alive across updates.
#
#   preserve.txt   one TOP-LEVEL file or folder name per line ("#" starts a comment).
#     name    kept if the new release does not ship something with that name. A folder the
#             release also ships (an empty backups/, say) gets your files merged back in.
#     @name   the same, and your copy is ALSO saved to pylon-saved/ whenever the release
#             replaces it, so an edited VoidScript.exe or bridge.py is never lost.
#
# This block is copied into the new update.py after every update (_pylon_after_swap), so
# the protection survives the updater itself being replaced by a release.
_PYLON_ALWAYS = ("preserve.txt", "pylon-saved")
_PYLON_KEEP_SNAPSHOTS = 3
_PYLON_BEGIN = "# >>> pylon-" + "preserve (begin)"
_PYLON_END = "# <<< pylon-" + "preserve (end)"
_PYLON_PRESERVE_RE = re.compile(r"^PRESERVE\s*=\s*(\{[^{}\n]*\})[ \t]*$", re.M)
_PYLON_ANCHOR_BEFORE = '        park = sorted(PRESERVE | {"update.py", "update.bat"})\n'
_PYLON_ANCHOR_AFTER = '        write_state({"last_check": int(time.time()), "last_tag": tag, "last_url": url, "applied_tag": tag})\n'


def _pylon_root():
    return os.path.dirname(os.path.abspath(__file__))


def _pylon_log(root, text):
    try:
        os.makedirs(os.path.join(root, "logs"), exist_ok=True)
        with open(os.path.join(root, "logs", "update-preserve.log"), "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + text + "\n")
    except Exception:
        pass


def _pylon_read_list(root=None):
    """(names to keep, names to also snapshot) from preserve.txt. Top-level names only."""
    root = root or _pylon_root()
    keep, snap = [], []
    try:
        with open(os.path.join(root, "preserve.txt"), "r", encoding="utf-8-sig") as f:
            lines = f.read().splitlines()
    except Exception:
        return keep, snap
    for line in lines[:500]:
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        want_snap = s.startswith("@")
        name = (s[1:] if want_snap else s).strip().strip('"')
        # a single plain name: no paths, no wildcards, nothing that can point outside this folder
        if (not name or len(name) > 120 or name in (".", "..", ".git")
                or any(c in name for c in '/\\:*?"<>|')):
            continue
        keep.append(name)
        if want_snap:
            snap.append(name)
    return keep, snap


def _pylon_keep_names():
    return set(_PYLON_ALWAYS) | set(_pylon_read_list()[0])


def _pylon_snapshot(root, extracted, tag):
    """Before the swap: save the '@' files the release is about to replace."""
    try:
        import filecmp
        snap = _pylon_read_list(root)[1]
        stamp = time.strftime("%Y%m%d-%H%M%S") + "-" + re.sub(r"[^\w.\-]", "_", str(tag))[:30]
        dest, saved = os.path.join(root, "pylon-saved", stamp), []
        for name in snap:
            src, new = os.path.join(root, name), os.path.join(extracted, name)
            if not os.path.exists(src) or os.path.islink(src):
                continue
            if os.path.isfile(src) and os.path.isfile(new) and filecmp.cmp(src, new, shallow=False):
                continue  # the release ships the very same file: nothing to save
            os.makedirs(dest, exist_ok=True)
            if os.path.isdir(src):
                shutil.copytree(src, os.path.join(dest, name))
            else:
                shutil.copy2(src, os.path.join(dest, name))
            saved.append(name)
        if saved:
            _pylon_log(root, "saved before update %s: %s -> pylon-saved/%s" % (tag, ", ".join(saved), stamp))
        base = os.path.join(root, "pylon-saved")
        if os.path.isdir(base):
            olds = sorted(d for d in os.listdir(base) if os.path.isdir(os.path.join(base, d)))
            for d in olds[:-_PYLON_KEEP_SNAPSHOTS]:
                shutil.rmtree(os.path.join(base, d), ignore_errors=True)
    except Exception as e:
        _pylon_log(root, "snapshot failed (the update continues): %s" % e)


def _pylon_merge(src, dst):
    """Copy what is in src but not in dst. Never overwrites. Returns how many items were copied."""
    n = 0
    for entry in os.listdir(src):
        s, d = os.path.join(src, entry), os.path.join(dst, entry)
        if os.path.islink(s):
            continue
        if not os.path.exists(d):
            if os.path.isdir(s):
                shutil.copytree(s, d)
            else:
                shutil.copy2(s, d)
            n += 1
        elif os.path.isdir(s) and os.path.isdir(d):
            n += _pylon_merge(s, d)
    return n


def _pylon_block(text):
    """The text of this block inside a copy of update.py, or None."""
    text = text.replace("\r\n", "\n")
    a, b = text.find(_PYLON_BEGIN), text.find(_PYLON_END)
    if a < 0 or b < a:
        return None
    b = text.find("\n", b)
    return text[a:] if b < 0 else text[a:b + 1]


def _pylon_patch(text, block, root):
    """update.py text with this block wired in, or None if the file does not look as expected
    or the result does not compile and behave."""
    t = text.replace("\r\n", "\n")
    found = list(_PYLON_PRESERVE_RE.finditer(t))
    if len(found) != 1 or t.count(_PYLON_ANCHOR_BEFORE) != 1 or t.count(_PYLON_ANCHOR_AFTER) != 1:
        return None
    m = found[0]
    t = (t[:m.start()] + block + "\nPRESERVE = " + m.group(1) + " | _pylon_keep_names()" + t[m.end():])
    t = t.replace(_PYLON_ANCHOR_BEFORE, "        _pylon_snapshot(root, extracted, tag)\n" + _PYLON_ANCHOR_BEFORE)
    t = t.replace(_PYLON_ANCHOR_AFTER, "        _pylon_after_swap(root, backup, quiet)\n" + _PYLON_ANCHOR_AFTER)
    try:  # it must compile, define the hooks and actually protect preserve.txt
        ns = {"__name__": "pylon_check", "__file__": os.path.join(root, "update.py")}
        exec(compile(t, "update.py", "exec"), ns)
        if not (callable(ns.get("_pylon_after_swap")) and callable(ns.get("_pylon_snapshot"))
                and "preserve.txt" in ns.get("PRESERVE", ())):
            return None
    except Exception:
        return None
    return t


def _pylon_after_swap(root, backup, quiet=True):
    """After the release is in place: merge parked folders into same-named release folders, and
    make sure the update.py now on disk still carries this block."""
    notes = []
    try:
        # every protected name, including the built-in config.json / logs: a release that ships a
        # folder of the same name (even logs/) must not swallow what was parked from the old one
        names = set(globals().get("PRESERVE", ())) | set(_PYLON_ALWAYS) | set(_pylon_read_list(root)[0])
        for name in sorted(names):
            src, dst = os.path.join(backup, name), os.path.join(root, name)
            if os.path.isdir(src) and os.path.isdir(dst) and not os.path.islink(dst):
                n = _pylon_merge(src, dst)
                if n:
                    notes.append("merged %d item(s) of '%s' back into the new release" % (n, name))
        new_py, old_py = os.path.join(root, "update.py"), os.path.join(backup, "update.py")
        if not (os.path.isfile(new_py) and os.path.isfile(old_py)):
            return  # the release shipped no updater, so ours was put back untouched
        with open(new_py, "r", encoding="utf-8") as f:
            new_text = f.read()
        if _PYLON_BEGIN in new_text:
            return
        with open(old_py, "r", encoding="utf-8") as f:
            block = _pylon_block(f.read())
        patched = _pylon_patch(new_text, block, root) if block else None
        if patched:
            with open(new_py, "w", encoding="utf-8", newline="\n") as f:
                f.write(patched)
            notes.append("carried the preserve list into the new update.py")
        else:
            shutil.copy2(new_py, os.path.join(root, "update.upstream.py"))
            shutil.copy2(old_py, new_py)
            notes.append("the new update.py could not be patched: kept the previous updater "
                         "(the release's copy is saved as update.upstream.py)")
    except Exception as e:
        notes.append("post-update step failed (your files were already restored): %s" % e)
    finally:
        for line in notes:  # written last: logs/ may itself have been merged above
            _pylon_log(root, line)
# <<< pylon-preserve (end)

PRESERVE = {"config.json", "logs"} | _pylon_keep_names()
USER_AGENT = "VoidScript-Updater/2.0"


def log(msg):
    print(msg, flush=True)


def norm_tag(tag):
    # "V1.1.0" -> [1, 1, 0]; "2.0.0" -> [2, 0, 0]
    m = re.findall(r"\d+", str(tag))
    return [int(x) for x in m[:3]] + [0] * (3 - len(m))


def is_newer(a, b):
    return norm_tag(a) > norm_tag(b)


def read_installed_version():
    # The manifest version, OR the last successfully APPLIED release tag
    # (whichever is higher). A maintainer may tag V2.0.1 but ship a zip whose
    # manifest still says 2.0.0; we apply the tag anyway, and remembering it
    # here stops the updater from re-applying the same release every launch.
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "voidscript-extension", "manifest.json")
    manifest = "0.0.0"
    try:
        with open(p, "r", encoding="utf-8") as f:
            manifest = json.load(f).get("version", "0.0.0")
    except Exception:
        pass
    applied = read_state().get("applied_tag", "")
    if applied and is_newer(applied, manifest):
        return applied
    return manifest


def read_state():
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"last_check": 0, "last_tag": "", "last_url": ""}


def write_state(state):
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(state, f)
    except Exception:
        pass


def fetch_latest():
    req = urllib.request.Request(API, headers={"User-Agent": USER_AGENT, "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=20) as resp:
        return json.load(resp)


def latest_release():
    data = fetch_latest()
    tag = data.get("tag_name", "")
    assets = data.get("assets") or []
    url = ""
    for a in assets:
        if a.get("browser_download_url"):
            url = a["browser_download_url"]
            break
    if not url:
        # No uploaded asset -> fall back to the source tarball of the tag.
        url = data.get("tarball_url", "")
    return tag, url, assets


def check_mode():
    now = int(time.time())
    state = read_state()
    installed = read_installed_version()
    # TTL: reuse the last API answer for an hour so repeated start.bat launches
    # are instant and don't burn the anonymous GitHub rate limit.
    if now - state.get("last_check", 0) < CHECK_TTL_SEC and state.get("last_tag"):
        tag = state["last_tag"]
    else:
        try:
            tag, url, _assets = latest_release()
        except Exception:
            # Offline / rate-limited / repo changed: stay silent, never block
            # startup and never print something start.bat would misread as a
            # version bump. Reuse the last known tag (or nothing).
            tag = state.get("last_tag", "")
            url = state.get("last_url", "")
        if tag:
            write_state({"last_check": now, "last_tag": tag, "last_url": url,
                         "applied_tag": state.get("applied_tag", "")})
    if tag and is_newer(tag, installed):
        log(f"UPDATE_AVAILABLE {tag}")
    return 0


def download(url, dest):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=120) as resp:
        with open(dest, "wb") as f:
            shutil.copyfileobj(resp, f)


def extract(archive, dest_dir):
    if zipfile.is_zipfile(archive):
        with zipfile.ZipFile(archive) as z:
            z.extractall(dest_dir)
    else:
        # A GitHub tarball fallback (rare: no release asset uploaded).
        import tarfile
        with tarfile.open(archive, "r:*") as t:
            t.extractall(dest_dir)


def move_over(src, dst):
    # Replace dst even if it somehow survived the wipe (e.g. the running
    # start.bat that cmd keeps an open handle on).
    if os.path.exists(dst):
        if os.path.isdir(dst) and not os.path.islink(dst):
            shutil.rmtree(dst, ignore_errors=True)
        else:
            try:
                os.remove(dst)
            except OSError:
                # A running VoidScript.exe can't be deleted or overwritten, but
                # Windows does allow RENAMING it. Move it aside as *.old (the
                # launcher deletes those on its next start) so the new file can
                # take its place - instead of shutil.move failing half-way through
                # the swap and leaving a wiped, half-installed folder.
                try:
                    os.replace(dst, "%s.%d.old" % (dst, int(time.time() * 1000)))
                except OSError:
                    pass
    shutil.move(src, dst)


def clean_stale():
    # Best-effort removal of files a previous update renamed aside (see move_over).
    root = os.path.dirname(os.path.abspath(__file__))
    try:
        for name in os.listdir(root):
            if name.endswith(".old"):
                try:
                    os.remove(os.path.join(root, name))
                except OSError:
                    pass  # still in use; the next run gets it
    except OSError:
        pass


def perform_swap(tag, url, quiet=False):
    root = os.path.dirname(os.path.abspath(__file__))
    if not quiet:
        log(f"[update] New release {tag}. Downloading...")
    tmp = tempfile.mkdtemp(prefix="vs_update_")
    try:
        archive = os.path.join(tmp, "release.bin")
        download(url, archive)
        if not quiet:
            log("[update] Downloaded. Extracting...")
        extracted = os.path.join(tmp, "extract")
        os.makedirs(extracted, exist_ok=True)
        extract(archive, extracted)
        # The extract may leave a single top-level folder (GitHub tarball style).
        entries = os.listdir(extracted)
        if len(entries) == 1 and os.path.isdir(os.path.join(extracted, entries[0])):
            extracted = os.path.join(extracted, entries[0])
        # Sanity: a real VoidScript release always ships these.
        if not os.path.exists(os.path.join(extracted, "bridge.py")) or not os.path.exists(
            os.path.join(extracted, "voidscript-extension", "manifest.json")
        ):
            if not quiet:
                log("[update] Downloaded file does not look like a VoidScript release. Aborting - nothing was changed.")
            return False
        new_version = "0.0.0"
        try:
            with open(os.path.join(extracted, "voidscript-extension", "manifest.json"), "r", encoding="utf-8") as f:
                new_version = json.load(f).get("version", "0.0.0")
        except Exception:
            pass
        installed = read_installed_version()
        # The GitHub release TAG is the source of truth for "is this newer?" -
        # a maintainer can tag V2.0.1 and forget to bump the manifest inside the
        # zip, and the extracted manifest would then read the old number and
        # wrongly abort the update. Compare the tag first; fall back to the
        # extracted manifest only when the tag has no digits at all.
        if is_newer(tag, installed):
            if not quiet:
                log(f"[update] Extracted release is newer (tag {tag} > installed {installed}). Proceeding.")
        elif is_newer(new_version, installed):
            if not quiet:
                log(f"[update] Extracted release is newer (manifest {new_version} > installed {installed}). Proceeding.")
        else:
            if not quiet:
                log(f"[update] Extracted release is not newer than installed ({installed}). Aborting.")
            return False

        if not quiet:
            log(f"[update] Swapping files (v{installed} -> v{new_version})...")
        backup = os.path.join(tmp, "preserved")
        os.makedirs(backup, exist_ok=True)
        # Park the things a release must never clobber (user data) plus the
        # updater itself (a release zip might not ship update.py/update.bat).
        _pylon_snapshot(root, extracted, tag)
        park = sorted(PRESERVE | {"update.py", "update.bat"})
        for keep in park:
            src = os.path.join(root, keep)
            if os.path.exists(src):
                shutil.move(src, os.path.join(backup, keep))
        git = os.path.join(root, ".git")
        git_parked = False
        if os.path.exists(git):
            shutil.move(git, os.path.join(backup, ".git"))
            git_parked = True
        # Wipe the project (except what we parked) and move the release in.
        for entry in os.listdir(root):
            p = os.path.join(root, entry)
            if os.path.isdir(p) and not os.path.islink(p):
                shutil.rmtree(p, ignore_errors=True)
            else:
                try:
                    os.remove(p)
                except OSError:
                    pass
        for entry in os.listdir(extracted):
            move_over(os.path.join(extracted, entry), os.path.join(root, entry))
        restore = park[:]
        if git_parked:
            restore.append(".git")
        # Restore parked paths, but only where the new release doesn't already
        # ship its own copy (e.g. a newer update.py must win; user config and
        # logs always win since a release never contains real user data). .git
        # is restored unconditionally when we parked it.
        for keep in restore:
            if not os.path.exists(os.path.join(root, keep)) and os.path.exists(os.path.join(backup, keep)):
                shutil.move(os.path.join(backup, keep), os.path.join(root, keep))
        _pylon_after_swap(root, backup, quiet)
        write_state({"last_check": int(time.time()), "last_tag": tag, "last_url": url, "applied_tag": tag})
        if not quiet:
            log(f"[update] Done! Updated to v{new_version} (release tag {tag}).")
            log("Reload the extension in chrome://extensions, then run start.bat again.")
            if git_parked:
                log("(Local git history preserved - working tree now shows the release as uncommitted changes.)")
        return True
    except Exception as e:
        if not quiet:
            log(f"[update] Update failed: {e}")
        return False
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def auto_mode():
    # Used by start.bat on every launch: a newer GitHub release is downloaded
    # and applied automatically. Silent unless it actually updated (then it
    # prints "UPDATE_APPLIED <tag>"), and it never blocks startup on errors.
    now = int(time.time())
    state = read_state()
    installed = read_installed_version()
    if now - state.get("last_check", 0) < CHECK_TTL_SEC and state.get("last_tag"):
        tag = state.get("last_tag")
        url = state.get("last_url", "")
    else:
        try:
            tag, url, _assets = latest_release()
        except Exception:
            return 0
        if tag:
            # Preserve applied_tag: this write replaces the whole state file, and
            # dropping the tag of an already-applied release would let a future
            # launch re-download + re-apply it (and re-trigger start.bat's
            # restart chain) because read_installed_version() would no longer see it.
            write_state({"last_check": now, "last_tag": tag, "last_url": url,
                         "applied_tag": state.get("applied_tag", "")})
    if not tag or not url or not is_newer(tag, installed):
        return 0
    if perform_swap(tag, url, quiet=True):
        log(f"UPDATE_APPLIED {tag}")
    return 0


def full_mode():
    installed = read_installed_version()
    try:
        tag, url, assets = latest_release()
    except Exception as e:
        log(f"[update] Could not reach GitHub: {e}")
        return 1
    if not url:
        log("[update] Release found but it has no downloadable asset.")
        return 1
    if not is_newer(tag, installed):
        log(f"[update] Already up to date (installed {installed}, latest {tag}).")
        write_state({"last_check": int(time.time()), "last_tag": tag, "last_url": url})
        return 0
    return 0 if perform_swap(tag, url, quiet=False) else 1


def main():
    clean_stale()
    if len(sys.argv) > 1 and sys.argv[1] == "--check":
        return check_mode()
    if len(sys.argv) > 1 and sys.argv[1] == "--auto":
        return auto_mode()
    return full_mode()


if __name__ == "__main__":
    sys.exit(main())
